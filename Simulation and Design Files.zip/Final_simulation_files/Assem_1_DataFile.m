% Simscape(TM) Multibody(TM) version: 6.0

% This is a model data file derived from a Simscape Multibody Import XML file using the smimport function.
% The data in this file sets the block parameter values in an imported Simscape Multibody model.
% For more information on this file, see the smimport function help page in the Simscape Multibody documentation.
% You can modify numerical values, but avoid any other changes to this file.
% Do not add code to this file. Do not edit the physical units shown in comments.

%%%VariableName:smiData


%============= RigidTransform =============%

%Initialize the RigidTransform structure array by filling in null values.
smiData.RigidTransform(37).translation = [0.0 0.0 0.0];
smiData.RigidTransform(37).angle = 0.0;
smiData.RigidTransform(37).axis = [0.0 0.0 0.0];
smiData.RigidTransform(37).ID = '';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(1).translation = [0 0 8.0000000000000071];  % mm
smiData.RigidTransform(1).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(1).axis = [1 0 0];
smiData.RigidTransform(1).ID = 'B[revolving joint-12:-:leg with base-5]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(2).translation = [-9.539036227579345e-13 35.999999999999638 11.999999999999556];  % mm
smiData.RigidTransform(2).angle = 3.1415926535897927;  % rad
smiData.RigidTransform(2).axis = [-1 -2.4009666711638428e-31 7.0590396602052023e-16];
smiData.RigidTransform(2).ID = 'F[revolving joint-12:-:leg with base-5]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(3).translation = [0 0 8.0000000000000071];  % mm
smiData.RigidTransform(3).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(3).axis = [1 0 0];
smiData.RigidTransform(3).ID = 'B[revolving joint-13:-:leg with base-5]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(4).translation = [-31.176914536236389 -18.000000000002682 12.000000000000849];  % mm
smiData.RigidTransform(4).angle = 3.1415926535897927;  % rad
smiData.RigidTransform(4).axis = [1 2.2179838511591712e-32 5.711363657717448e-17];
smiData.RigidTransform(4).ID = 'F[revolving joint-13:-:leg with base-5]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(5).translation = [0 0 8.0000000000000071];  % mm
smiData.RigidTransform(5).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(5).axis = [1 0 5.5511151231257827e-17];
smiData.RigidTransform(5).ID = 'B[revolving joint-14:-:leg with base-5]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(6).translation = [31.176914536235589 -18.000000000001847 12.000000000000913];  % mm
smiData.RigidTransform(6).angle = 3.1415926535897913;  % rad
smiData.RigidTransform(6).axis = [1 -1.2862942400475643e-30 -1.2215043993657967e-15];
smiData.RigidTransform(6).ID = 'F[revolving joint-14:-:leg with base-5]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(7).translation = [0 71.720597874151451 8.0000000000000071];  % mm
smiData.RigidTransform(7).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(7).axis = [1 4.3333423748712807e-33 8.3266726846886741e-17];
smiData.RigidTransform(7).ID = 'B[link-1:-:servo_arm-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(8).translation = [50.000000000006047 -1.5646151041437406e-11 1.9999999999953673];  % mm
smiData.RigidTransform(8).angle = 5.4290359981217911e-15;  % rad
smiData.RigidTransform(8).axis = [-0.4410545363054395 0.89748030396460154 -1.0745087223505111e-15];
smiData.RigidTransform(8).ID = 'F[link-1:-:servo_arm-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(9).translation = [50.000000000000007 0 -2.0000000000000155];  % mm
smiData.RigidTransform(9).angle = 0;  % rad
smiData.RigidTransform(9).axis = [0 0 0];
smiData.RigidTransform(9).ID = 'B[servo_arm-2:-:link-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(10).translation = [8.8462570602132473e-12 71.720597874151963 -3.9999999999997442];  % mm
smiData.RigidTransform(10).angle = 1.1955051700974648e-15;  % rad
smiData.RigidTransform(10).axis = [-0.99144460421775649 -0.13052814549933717 7.7356014159666233e-17];
smiData.RigidTransform(10).ID = 'F[servo_arm-2:-:link-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(11).translation = [49.999999999999986 0 -1.999999999999974];  % mm
smiData.RigidTransform(11).angle = 0;  % rad
smiData.RigidTransform(11).axis = [0 0 0];
smiData.RigidTransform(11).ID = 'B[servo_arm-3:-:link-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(12).translation = [-5.8495430721450248e-12 71.720597874159694 -4.0000000000027285];  % mm
smiData.RigidTransform(12).angle = 4.3236826430936352e-15;  % rad
smiData.RigidTransform(12).axis = [-0.68961496239046782 0.72417622416590943 -1.0796295217810257e-15];
smiData.RigidTransform(12).ID = 'F[servo_arm-3:-:link-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(13).translation = [9.0000000000000071 -35.779402125848556 3.999999999999976];  % mm
smiData.RigidTransform(13).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(13).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(13).ID = 'B[link-3:-:double hinge block-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(14).translation = [12.499999999999819 15.001651646903618 2.9999999999996252];  % mm
smiData.RigidTransform(14).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(14).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(14).ID = 'F[link-3:-:double hinge block-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(15).translation = [0 3.999999999999976 6.0000000000000053];  % mm
smiData.RigidTransform(15).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(15).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(15).ID = 'B[revolving joint-14:-:double hinge block-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(16).translation = [3.5000000000004183 10.001651646902651 -0.99999999999984901];  % mm
smiData.RigidTransform(16).angle = 1.7798229048217483e-15;  % rad
smiData.RigidTransform(16).axis = [-0.95360802050708504 0.30105106414786004 -2.5547997066580898e-16];
smiData.RigidTransform(16).ID = 'F[revolving joint-14:-:double hinge block-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(17).translation = [8.9999999999999947 -35.779402125848542 4.0000000000000036];  % mm
smiData.RigidTransform(17).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(17).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(17).ID = 'B[link-2:-:double hinge block-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(18).translation = [-5.4999999999998925 15.00165164690166 2.9999999999993174];  % mm
smiData.RigidTransform(18).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(18).axis = [0.57735026918962595 0.57735026918962562 0.57735026918962562];
smiData.RigidTransform(18).ID = 'F[link-2:-:double hinge block-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(19).translation = [0 4.0000000000000036 6.0000000000000053];  % mm
smiData.RigidTransform(19).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(19).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(19).ID = 'B[revolving joint-12:-:double hinge block-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(20).translation = [3.4999999999977085 10.00165164690136 -0.99999999999997335];  % mm
smiData.RigidTransform(20).angle = 3.0116418308224173e-15;  % rad
smiData.RigidTransform(20).axis = [-0.82169045318189438 0.56993403052435221 -7.0519001686126102e-16];
smiData.RigidTransform(20).ID = 'F[revolving joint-12:-:double hinge block-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(21).translation = [8.9999999999999805 -35.779402125848542 4.0000000000000036];  % mm
smiData.RigidTransform(21).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(21).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(21).ID = 'B[link-1:-:double hinge block-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(22).translation = [-5.5000000000005045 15.001651646903245 3.0000000000012026];  % mm
smiData.RigidTransform(22).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(22).axis = [0.57735026918962584 0.57735026918962562 0.57735026918962584];
smiData.RigidTransform(22).ID = 'F[link-1:-:double hinge block-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(23).translation = [0 4.0000000000000036 5.9999999999999911];  % mm
smiData.RigidTransform(23).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(23).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(23).ID = 'B[revolving joint-13:-:double hinge block-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(24).translation = [3.5000000000003126 10.001651646901911 7.0000000000005755];  % mm
smiData.RigidTransform(24).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(24).axis = [1 -2.0431976024294742e-31 -1.753744063787506e-15];
smiData.RigidTransform(24).ID = 'F[revolving joint-13:-:double hinge block-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(25).translation = [0 45.250000000000014 10.059999999999986];  % mm
smiData.RigidTransform(25).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(25).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(25).ID = 'B[Servo Motor-1:-:servo_arm-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(26).translation = [8.4969808966661731e-12 -1.0467182676165976e-11 5.6999999999997986];  % mm
smiData.RigidTransform(26).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(26).axis = [1 2.259763934272038e-32 2.6806074531685163e-16];
smiData.RigidTransform(26).ID = 'F[Servo Motor-1:-:servo_arm-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(27).translation = [-9.1750000000000096 31.799999999999994 -27.099999999999984];  % mm
smiData.RigidTransform(27).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(27).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(27).ID = 'B[Servo Motor-1:-:tri leg base-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(28).translation = [32.163963493327032 -35.890381056767019 21.35000000000003];  % mm
smiData.RigidTransform(28).angle = 1.6378338249998246;  % rad
smiData.RigidTransform(28).axis = [-0.93511312653102818 0.2505628070857337 -0.25056280708573375];
smiData.RigidTransform(28).ID = 'F[Servo Motor-1:-:tri leg base-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(29).translation = [0 45.249999999999986 10.059999999999986];  % mm
smiData.RigidTransform(29).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(29).axis = [0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(29).ID = 'B[Servo Motor-2:-:servo_arm-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(30).translation = [5.9166005428323842e-12 -5.1940673984063324e-12 5.7000000000000632];  % mm
smiData.RigidTransform(30).angle = 3.1415926535897918;  % rad
smiData.RigidTransform(30).axis = [1 1.4935587506127357e-31 2.1701050100878247e-16];
smiData.RigidTransform(30).ID = 'F[Servo Motor-2:-:servo_arm-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(31).translation = [-94.102540378444189 -37.009618943232489 25.999999999999989];  % mm
smiData.RigidTransform(31).angle = 1.8234765819369796;  % rad
smiData.RigidTransform(31).axis = [-0.44721359549996076 -0.77459666924148007 -0.44721359549996076];
smiData.RigidTransform(31).ID = 'B[tri leg base-1:-:Servo Motor-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(32).translation = [-13.825000000000022 31.799999999999926 27.100000000000048];  % mm
smiData.RigidTransform(32).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(32).axis = [-5.5511151231257827e-17 0.70710678118654746 -0.70710678118654757];
smiData.RigidTransform(32).ID = 'F[tri leg base-1:-:Servo Motor-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(33).translation = [0 45.250000000000014 10.059999999999986];  % mm
smiData.RigidTransform(33).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(33).axis = [0.57735026918962584 -0.57735026918962573 0.57735026918962573];
smiData.RigidTransform(33).ID = 'B[Servo Motor-3:-:servo_arm-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(34).translation = [-8.6872731230869249e-12 9.0085716664134452e-12 5.7000000000000108];  % mm
smiData.RigidTransform(34).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(34).axis = [1 5.6218970666511829e-33 5.6486088188556646e-17];
smiData.RigidTransform(34).ID = 'F[Servo Motor-3:-:servo_arm-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(35).translation = [15.000000000000014 99.999999999999986 25.999999999999989];  % mm
smiData.RigidTransform(35).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(35).axis = [0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(35).ID = 'B[tri leg base-1:-:Servo Motor-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(36).translation = [-13.825000000000024 31.799999999999994 27.099999999999966];  % mm
smiData.RigidTransform(36).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(36).axis = [0.57735026918962584 -0.57735026918962573 0.57735026918962573];
smiData.RigidTransform(36).ID = 'F[tri leg base-1:-:Servo Motor-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(37).translation = [-54.002821769088733 -192.2365035915044 -2.6534985048567998];  % mm
smiData.RigidTransform(37).angle = 2.2618657464539988;  % rad
smiData.RigidTransform(37).axis = [0.052143236481269867 0.99531528928952795 -0.081415955412693752];
smiData.RigidTransform(37).ID = 'RootGround[tri leg base-1]';


%============= Solid =============%
%Center of Mass (CoM) %Moments of Inertia (MoI) %Product of Inertia (PoI)

%Initialize the Solid structure array by filling in null values.
smiData.Solid(7).mass = 0.0;
smiData.Solid(7).CoM = [0.0 0.0 0.0];
smiData.Solid(7).MoI = [0.0 0.0 0.0];
smiData.Solid(7).PoI = [0.0 0.0 0.0];
smiData.Solid(7).color = [0.0 0.0 0.0];
smiData.Solid(7).opacity = 0.0;
smiData.Solid(7).ID = '';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(1).mass = 0.033531280401292378;  % kg
smiData.Solid(1).CoM = [0 20.00039868649381 0.090769349293324669];  % mm
smiData.Solid(1).MoI = [9.2917061140214141 6.0077457991379477 5.5788051989043765];  % kg*mm^2
smiData.Solid(1).PoI = [-0.01427482567175635 0 0];  % kg*mm^2
smiData.Solid(1).color = [0.20862745098039215 0.20862745098039215 0.20862745098039215];
smiData.Solid(1).opacity = 1;
smiData.Solid(1).ID = 'Servo Motor*:*Predeterminado';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(2).mass = 0.0024171751826642567;  % kg
smiData.Solid(2).CoM = [17.134239764369894 0 5.3140708579061835];  % mm
smiData.Solid(2).MoI = [0.029430717532879843 0.63660080468988056 0.6482811154888819];  % kg*mm^2
smiData.Solid(2).PoI = [0 -0.026526696775913947 0];  % kg*mm^2
smiData.Solid(2).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(2).opacity = 1;
smiData.Solid(2).ID = 'servo_arm*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(3).mass = 0.0002366570826471148;  % kg
smiData.Solid(3).CoM = [0 0 2.5833512603850743];  % mm
smiData.Solid(3).MoI = [0.0028271600326655894 0.0024335662685354238 0.0032551663154415027];  % kg*mm^2
smiData.Solid(3).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(3).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(3).opacity = 1;
smiData.Solid(3).ID = 'revolving joint*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(4).mass = 0.00025460841488249845;  % kg
smiData.Solid(4).CoM = [3.4999999999999996 12.899629621707732 2.9999999999999991];  % mm
smiData.Solid(4).MoI = [0.0023141574988352191 0.0019662203033670236 0.0025115119019738109];  % kg*mm^2
smiData.Solid(4).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(4).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(4).opacity = 1;
smiData.Solid(4).ID = 'double hinge block*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(5).mass = 0.11500251261662846;  % kg
smiData.Solid(5).CoM = [0 0 13.056150947079983];  % mm
smiData.Solid(5).MoI = [126.28799527532588 126.28799527532631 239.12038598532681];  % kg*mm^2
smiData.Solid(5).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(5).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(5).opacity = 1;
smiData.Solid(5).ID = 'tri leg base*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(6).mass = 0.025495068679751376;  % kg
smiData.Solid(6).CoM = [0 0 -39.468829167256594];  % mm
smiData.Solid(6).MoI = [51.331844609416748 51.331844609416734 5.0544095159851876];  % kg*mm^2
smiData.Solid(6).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(6).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(6).opacity = 1;
smiData.Solid(6).ID = 'leg with base*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(7).mass = 0.015023159187053848;  % kg
smiData.Solid(7).CoM = [-7.7303028676752748e-13 16.396185269001389 4];  % mm
smiData.Solid(7).MoI = [13.905165079314843 0.49020286369805077 14.230797183485294];  % kg*mm^2
smiData.Solid(7).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(7).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(7).opacity = 1;
smiData.Solid(7).ID = 'link*:*Default';


%============= Joint =============%
%X Revolute Primitive (Rx) %Y Revolute Primitive (Ry) %Z Revolute Primitive (Rz)
%X Prismatic Primitive (Px) %Y Prismatic Primitive (Py) %Z Prismatic Primitive (Pz) %Spherical Primitive (S)
%Constant Velocity Primitive (CV) %Lead Screw Primitive (LS)
%Position Target (Pos)

%Initialize the RevoluteJoint structure array by filling in null values.
smiData.RevoluteJoint(15).Rz.Pos = 0.0;
smiData.RevoluteJoint(15).ID = '';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.RevoluteJoint(1).Rz.Pos = -97.316633686493674;  % deg
smiData.RevoluteJoint(1).ID = '[revolving joint-12:-:leg with base-5]';

smiData.RevoluteJoint(2).Rz.Pos = 32.993122518407418;  % deg
smiData.RevoluteJoint(2).ID = '[revolving joint-13:-:leg with base-5]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.RevoluteJoint(3).Rz.Pos = -31.638551163962969;  % deg
smiData.RevoluteJoint(3).ID = '[revolving joint-14:-:leg with base-5]';

smiData.RevoluteJoint(4).Rz.Pos = -158.13389833449151;  % deg
smiData.RevoluteJoint(4).ID = '[link-1:-:servo_arm-1]';

smiData.RevoluteJoint(5).Rz.Pos = -21.655034244215333;  % deg
smiData.RevoluteJoint(5).ID = '[servo_arm-2:-:link-2]';

smiData.RevoluteJoint(6).Rz.Pos = -17.064575323155683;  % deg
smiData.RevoluteJoint(6).ID = '[servo_arm-3:-:link-3]';

smiData.RevoluteJoint(7).Rz.Pos = 0.46124503834033143;  % deg
smiData.RevoluteJoint(7).ID = '[link-3:-:double hinge block-1]';

smiData.RevoluteJoint(8).Rz.Pos = -137.80584444104579;  % deg
smiData.RevoluteJoint(8).ID = '[revolving joint-14:-:double hinge block-1]';

smiData.RevoluteJoint(9).Rz.Pos = -6.6141723107875361;  % deg
smiData.RevoluteJoint(9).ID = '[link-2:-:double hinge block-2]';

smiData.RevoluteJoint(10).Rz.Pos = -35.580834698844711;  % deg
smiData.RevoluteJoint(10).ID = '[revolving joint-12:-:double hinge block-2]';

smiData.RevoluteJoint(11).Rz.Pos = -6.1675244192516265;  % deg
smiData.RevoluteJoint(11).ID = '[link-1:-:double hinge block-3]';

smiData.RevoluteJoint(12).Rz.Pos = 145.00668004988691;  % deg
smiData.RevoluteJoint(12).ID = '[revolving joint-13:-:double hinge block-3]';

smiData.RevoluteJoint(13).Rz.Pos = 30.895576133401839;  % deg
smiData.RevoluteJoint(13).ID = '[Servo Motor-1:-:servo_arm-1]';

smiData.RevoluteJoint(14).Rz.Pos = 35.001277800601059;  % deg
smiData.RevoluteJoint(14).ID = '[Servo Motor-2:-:servo_arm-3]';

smiData.RevoluteJoint(15).Rz.Pos = 31.081212670827547;  % deg
smiData.RevoluteJoint(15).ID = '[Servo Motor-3:-:servo_arm-2]';

